#!/bin/bash
sudo yum install httpd -y
sudo service httpd start
echo "APACHE on RHEL8" > /var/www/html/index.html